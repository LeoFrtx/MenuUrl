-- ===== PLAYER COMMANDS =====

-- Commande pour admin
RegisterCommand('url', function(source, args, rawCommand)
    TriggerServerEvent('video:checkAdmin', 'openMenu')
end)

-- Commande pour arrêter
RegisterCommand('urls', function(source, args, rawCommand)
    TriggerServerEvent('video:checkAdmin', 'stopVideo')
end)