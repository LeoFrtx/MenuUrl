-- ===== VIDEO CLIENT =====

local videoPlaying = false

-- Jouer la vidéo
RegisterNetEvent('video:playVideoClient', function(videoUrl, videoTitle)
    videoPlaying = true
    
    SendNUIMessage({
        type = 'playVideo',
        url = videoUrl,
        title = videoTitle
    })
end)

-- Arrêter la vidéo
RegisterNetEvent('video:stopVideoClient', function()
    videoPlaying = false
    
    SendNUIMessage({
        type = 'stopVideo'
    })
end)

-- Demander la vidéo en cours au spawn
Citizen.CreateThread(function()
    Wait(500)
    TriggerServerEvent('video:getVideo')
end)

-- Input pour fermer la vidéo
Citizen.CreateThread(function()
    while true do
        Wait(0)
        if videoPlaying then
            if IsControlJustPressed(0, 177) then -- ESC
                videoPlaying = false
                SendNUIMessage({
                    type = 'stopVideo'
                })
            end
        end
    end
end)

-- NUI Callbacks pour la souris
RegisterNUICallback('enableMouse', function(data, cb)
    SetNuiFocus(true, true)
    cb('ok')
end)

RegisterNUICallback('disableMouse', function(data, cb)
    SetNuiFocus(false, false)
    cb('ok')
end)