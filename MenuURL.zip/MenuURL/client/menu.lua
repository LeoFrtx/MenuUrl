-- ===== MENU MANAGEMENT =====

RegisterNetEvent('video:openMenu', function()
    local input = lib.inputDialog('Lecture Vidéo', {
        {type = 'input', label = 'Lien Vidéo', placeholder = 'https://www.youtube.com/watch?v=...', required = true}
    })

    if not input then return end

    local url = input[1]
    local title = 'Vidéo'

    if url == '' then
        lib.notify({
            title = 'Erreur',
            description = 'Veuillez entrer un URL',
            type = 'error'
        })
        return
    end

    TriggerServerEvent('video:playVideo', url, title)
end)

-- Menu pour arrêter
RegisterNetEvent('video:stopMenu', function()
    TriggerServerEvent('video:stopVideo')
end)