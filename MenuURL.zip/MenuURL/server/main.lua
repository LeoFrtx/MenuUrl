-- ===== VIDEO SERVER =====

local currentVideo = nil
local videoStart = nil

-- Vérifier si c'est admin et exécuter l'action
RegisterNetEvent('video:checkAdmin', function(action)
    local src = source
    
    if not IsPlayerAceAllowed(src, 'video.admin') then
        TriggerClientEvent('ox_lib:notify', src, {
            title = 'Accès Refusé',
            description = 'Vous n\'avez pas accès à cette commande',
            type = 'error'
        })
        return
    end
    
    if action == 'openMenu' then
        TriggerClientEvent('video:openMenu', src)
    elseif action == 'stopVideo' then
        TriggerClientEvent('video:stopMenu', src)
    end
end)

-- Ouvrir le menu admin
RegisterCommand('videomenu', function(source, args, rawCommand)
    if not IsPlayerAceAllowed(source, 'video.admin') then
        TriggerClientEvent('ox_lib:notify', source, {
            title = 'Accès Refusé',
            description = 'Vous n\'avez pas accès à cette commande',
            type = 'error'
        })
        return
    end
    
    TriggerClientEvent('video:openMenu', source)
end)

-- Jouer une vidéo
RegisterNetEvent('video:playVideo', function(videoUrl, videoTitle)
    local src = source
    
    if not IsPlayerAceAllowed(src, 'video.admin') then
        TriggerClientEvent('ox_lib:notify', src, {
            title = 'Accès Refusé',
            description = 'Vous n\'avez pas accès à cette commande',
            type = 'error'
        })
        return
    end
    
    -- Valider l'URL
    if not videoUrl or videoUrl == '' then
        TriggerClientEvent('ox_lib:notify', src, {
            title = 'Erreur',
            description = 'URL vide',
            type = 'error'
        })
        return
    end
    
    -- Vérifier que c'est un lien valide
    if not string.match(videoUrl, 'youtube.com') and not string.match(videoUrl, 'youtu.be') and
       not string.match(videoUrl, 'youtube-nocookie.com') and not string.match(videoUrl, 'vimeo.com') then
        TriggerClientEvent('ox_lib:notify', src, {
            title = 'Erreur',
            description = 'Utilisez un lien vidéo valide',
            type = 'error'
        })
        return
    end
    
    currentVideo = {
        url = videoUrl,
        title = videoTitle or 'Vidéo',
        startTime = GetGameTimer()
    }
    videoStart = GetGameTimer()
    
    TriggerClientEvent('video:playVideoClient', -1, videoUrl, videoTitle)
    
    TriggerClientEvent('ox_lib:notify', src, {
        title = 'Succès',
        description = 'Vidéo lancée: ' .. (videoTitle or 'Vidéo'),
        type = 'success'
    })
    
    print('^2[VIDEO] Vidéo lancée par ' .. GetPlayerName(src) .. ': ' .. videoUrl .. '^7')
end)

-- Arrêter la vidéo
RegisterNetEvent('video:stopVideo', function()
    local src = source
    
    if not IsPlayerAceAllowed(src, 'video.admin') then return end
    
    currentVideo = nil
    videoStart = nil
    
    TriggerClientEvent('video:stopVideoClient', -1)
    
    TriggerClientEvent('ox_lib:notify', src, {
        title = 'Succès',
        description = 'Vidéo arrêtée',
        type = 'success'
    })
end)

-- Récupérer la vidéo en cours
RegisterNetEvent('video:getVideo', function()
    local src = source
    if currentVideo then
        TriggerClientEvent('video:playVideoClient', src, currentVideo.url, currentVideo.title)
    end
end)