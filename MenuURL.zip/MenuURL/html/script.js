// ===== VIDEO PLAYER =====

function extractVideoId(url) {
    // YouTube
    let regExp = /^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|\&v=)([^#\&\?]*).*/;
    let match = url.match(regExp);
    if (match && match[2].length === 11) {
        return {type: 'youtube', id: match[2]};
    }
    
    // Vimeo
    regExp = /^.*(vimeo.com\/)([0-9]+).*/;
    match = url.match(regExp);
    if (match && match[2]) {
        return {type: 'vimeo', id: match[2]};
    }
    
    return null;
}

function playVideo(url, title) {
    const videoData = extractVideoId(url);
    
    if (!videoData) {
        console.error('URL vidéo invalide');
        return;
    }
    
    let embedUrl;
    
    if (videoData.type === 'youtube') {
        embedUrl = `https://www.youtube-nocookie.com/embed/${videoData.id}?autoplay=1&controls=1&fs=1&modestbranding=1&rel=0`;
    } else if (videoData.type === 'vimeo') {
        embedUrl = `https://player.vimeo.com/video/${videoData.id}?autoplay=1`;
    } else {
        console.error('Type de vidéo non supporté');
        return;
    }
    
    const container = document.getElementById('playerContainer');
    const iframe = document.getElementById('videoFrame');
    const titleElement = document.getElementById('videoTitle');
    
    iframe.src = embedUrl;
    titleElement.textContent = title || 'Vidéo';
    container.classList.remove('hidden');
    
    // Activer la souris
    fetch(`https://${GetParentResourceName()}/enableMouse`, {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({})
    }).catch(() => {});
}

function stopVideo() {
    const container = document.getElementById('playerContainer');
    const iframe = document.getElementById('videoFrame');
    
    iframe.src = '';
    container.classList.add('hidden');
    
    // Désactiver la souris
    fetch(`https://${GetParentResourceName()}/disableMouse`, {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({})
    }).catch(() => {});
}

// Événements NUI
window.addEventListener('message', function(event) {
    const data = event.data;
    
    if (data.type === 'playVideo') {
        playVideo(data.url, data.title);
    } else if (data.type === 'stopVideo') {
        stopVideo();
    }
});

// Bouton Skip
document.getElementById('skipButton').addEventListener('click', function() {
    stopVideo();
});

// ESC pour fermer
document.addEventListener('keydown', function(event) {
    if (event.key === 'Escape') {
        stopVideo();
    }
});